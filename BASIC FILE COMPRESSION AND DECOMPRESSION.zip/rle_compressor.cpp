#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <iomanip>
using namespace std;

// Function to compress a string using Run-Length Encoding (RLE)
// Example: "AAAABBB" -> "A4B3"
string compressRLE(const string& data) {
    string compressed;
    int n = data.length();
    for (int i = 0; i < n;) {
        char current = data[i];
        int count = 1;
        while (i + count < n && data[i + count] == current) {
            count++;
        }
        compressed += current + to_string(count);
        i += count;
    }
    return compressed;
}

// Function to decompress a string compressed with RLE
// Example: "A4B3" -> "AAAABBB"
string decompressRLE(const string& data) {
    string decompressed;
    int i = 0;
    while (i < data.length()) {
        char ch = data[i++];
        string countStr;
        while (i < data.length() && isdigit(data[i])) {
            countStr += data[i++];
        }
        int count = stoi(countStr);
        decompressed.append(count, ch);
    }
    return decompressed;
}

// Function to read the content of a file and return it as a string
string readFile(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) throw runtime_error("Error: Cannot open input file.");
    return string((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
}

// Function to write a string to a file
void writeFile(const string& filename, const string& data) {
    ofstream file(filename);
    if (!file.is_open()) throw runtime_error("Error: Cannot write to output file.");
    file << data;
}

// Function to display compression statistics (original and compressed sizes and ratio)
void showStats(const string& original, const string& compressed) {
    size_t origSize = original.size();
    size_t compSize = compressed.size();
    double ratio = (double)compSize / origSize * 100;

    cout << fixed << setprecision(2);
    cout << "\n--- Compression Statistics ---\n";
    cout << "Original Size   : " << origSize << " bytes\n";
    cout << "Compressed Size : " << compSize << " bytes\n";
    cout << "Compression Ratio: " << ratio << " %\n\n";
}

// Function to display the menu options to the user
void showMenu() {
    cout << "\n======= RLE File Compressor =======\n";
    cout << "1. Compress File\n";
    cout << "2. Decompress File\n";
    cout << "0. Exit\n";
    cout << "Choose an option: ";
}

// Main function providing a user interface to compress/decompress files
int main() {
    int choice;
    string inputFile, outputFile;

    do {
        showMenu();
        cin >> choice;
        cin.ignore();  // flush newline

        try {
            if (choice == 1) {
                cout << "Enter input text file path: ";
                getline(cin, inputFile);
                cout << "Enter output file path (e.g., file.rle): ";
                getline(cin, outputFile);

                string data = readFile(inputFile);
                string compressed = compressRLE(data);
                writeFile(outputFile, compressed);
                cout << "File compressed successfully.\n";
                showStats(data, compressed);

            } else if (choice == 2) {
                cout << "Enter compressed file path (.rle): ";
                getline(cin, inputFile);
                cout << "Enter output text file path: ";
                getline(cin, outputFile);

                string data = readFile(inputFile);
                string decompressed = decompressRLE(data);
                writeFile(outputFile, decompressed);
                cout << "File decompressed successfully.\n";

            } else if (choice == 0) {
                cout << "Exiting the program.\n";
            } else {
                cout << "Invalid option. Try again.\n";
            }
        } catch (const exception& e) {
            cerr << e.what() << endl;
        }

    } while (choice != 0);

    return 0;
}
